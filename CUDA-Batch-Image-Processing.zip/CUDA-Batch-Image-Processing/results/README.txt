Save genuine execution screenshots and logs here after running the program in the CUDA lab.
