#include <cuda_runtime.h>

#include <algorithm>
#include <cctype>
#include <cstdint>
#include <filesystem>
#include <fstream>
#include <iostream>
#include <stdexcept>
#include <string>
#include <vector>

namespace fs = std::filesystem;

#define CUDA_CHECK(call)                                                     \
  do {                                                                       \
    cudaError_t error = (call);                                              \
    if (error != cudaSuccess) {                                              \
      throw std::runtime_error(std::string("CUDA error: ") +                 \
                               cudaGetErrorString(error));                   \
    }                                                                        \
  } while (0)

struct Image {
  int width = 0;
  int height = 0;
  std::vector<unsigned char> pixels;
};

__global__ void GrayscaleKernel(const unsigned char* input,
                                unsigned char* output, int width,
                                int height) {
  const int x = blockIdx.x * blockDim.x + threadIdx.x;
  const int y = blockIdx.y * blockDim.y + threadIdx.y;
  if (x >= width || y >= height) return;

  const int index = (y * width + x) * 3;
  const float red = input[index];
  const float green = input[index + 1];
  const float blue = input[index + 2];
  const unsigned char gray =
      static_cast<unsigned char>(0.299f * red + 0.587f * green + 0.114f * blue);

  output[index] = gray;
  output[index + 1] = gray;
  output[index + 2] = gray;
}

__global__ void GaussianBlurKernel(const unsigned char* input,
                                   unsigned char* output, int width,
                                   int height) {
  const int x = blockIdx.x * blockDim.x + threadIdx.x;
  const int y = blockIdx.y * blockDim.y + threadIdx.y;
  if (x >= width || y >= height) return;

  const int weights[3][3] = {{1, 2, 1}, {2, 4, 2}, {1, 2, 1}};
  const int total_weight = 16;
  for (int channel = 0; channel < 3; ++channel) {
    int sum = 0;
    for (int dy = -1; dy <= 1; ++dy) {
      for (int dx = -1; dx <= 1; ++dx) {
        const int sample_x = min(max(x + dx, 0), width - 1);
        const int sample_y = min(max(y + dy, 0), height - 1);
        const int sample_index = (sample_y * width + sample_x) * 3 + channel;
        sum += input[sample_index] * weights[dy + 1][dx + 1];
      }
    }
    output[(y * width + x) * 3 + channel] =
        static_cast<unsigned char>(sum / total_weight);
  }
}

std::string ReadToken(std::istream& input) {
  std::string token;
  char character;
  while (input.get(character)) {
    if (std::isspace(static_cast<unsigned char>(character))) continue;
    if (character == '#') {
      input.ignore(100000, '\n');
      continue;
    }
    token += character;
    break;
  }
  while (input.get(character)) {
    if (std::isspace(static_cast<unsigned char>(character))) break;
    token += character;
  }
  return token;
}

Image ReadPpm(const fs::path& path) {
  std::ifstream file(path, std::ios::binary);
  if (!file) throw std::runtime_error("Cannot open input image: " + path.string());

  const std::string magic = ReadToken(file);
  if (magic != "P6") {
    throw std::runtime_error("Only binary PPM (P6) images are supported: " +
                             path.string());
  }

  Image image;
  image.width = std::stoi(ReadToken(file));
  image.height = std::stoi(ReadToken(file));
  const int max_value = std::stoi(ReadToken(file));
  if (image.width <= 0 || image.height <= 0 || max_value != 255) {
    throw std::runtime_error("Invalid PPM dimensions or max value: " +
                             path.string());
  }

  const size_t byte_count =
      static_cast<size_t>(image.width) * image.height * 3;
  image.pixels.resize(byte_count);
  file.read(reinterpret_cast<char*>(image.pixels.data()),
            static_cast<std::streamsize>(byte_count));
  if (file.gcount() != static_cast<std::streamsize>(byte_count)) {
    throw std::runtime_error("Incomplete pixel data in: " + path.string());
  }
  return image;
}

void WritePpm(const fs::path& path, const Image& image,
              const std::vector<unsigned char>& pixels) {
  std::ofstream file(path, std::ios::binary);
  if (!file) throw std::runtime_error("Cannot write output image: " + path.string());
  file << "P6\n" << image.width << " " << image.height << "\n255\n";
  file.write(reinterpret_cast<const char*>(pixels.data()),
             static_cast<std::streamsize>(pixels.size()));
  if (!file) throw std::runtime_error("Failed while writing: " + path.string());
}

void ProcessImage(const fs::path& input_path, const fs::path& output_dir) {
  const Image image = ReadPpm(input_path);
  const size_t byte_count = image.pixels.size();

  unsigned char* device_input = nullptr;
  unsigned char* device_gray = nullptr;
  unsigned char* device_blur = nullptr;
  std::vector<unsigned char> gray(byte_count);
  std::vector<unsigned char> blur(byte_count);

  try {
    CUDA_CHECK(cudaMalloc(reinterpret_cast<void**>(&device_input), byte_count));
    CUDA_CHECK(cudaMalloc(reinterpret_cast<void**>(&device_gray), byte_count));
    CUDA_CHECK(cudaMalloc(reinterpret_cast<void**>(&device_blur), byte_count));
    CUDA_CHECK(cudaMemcpy(device_input, image.pixels.data(), byte_count,
                          cudaMemcpyHostToDevice));

    const dim3 block(16, 16);
    const dim3 grid((image.width + block.x - 1) / block.x,
                    (image.height + block.y - 1) / block.y);

    GrayscaleKernel<<<grid, block>>>(device_input, device_gray, image.width,
                                     image.height);
    GaussianBlurKernel<<<grid, block>>>(device_input, device_blur, image.width,
                                        image.height);
    CUDA_CHECK(cudaGetLastError());
    CUDA_CHECK(cudaDeviceSynchronize());

    CUDA_CHECK(cudaMemcpy(gray.data(), device_gray, byte_count,
                          cudaMemcpyDeviceToHost));
    CUDA_CHECK(cudaMemcpy(blur.data(), device_blur, byte_count,
                          cudaMemcpyDeviceToHost));

    const std::string stem = input_path.stem().string();
    WritePpm(output_dir / (stem + "_grayscale.ppm"), image, gray);
    WritePpm(output_dir / (stem + "_blur.ppm"), image, blur);
  } catch (...) {
    if (device_input) cudaFree(device_input);
    if (device_gray) cudaFree(device_gray);
    if (device_blur) cudaFree(device_blur);
    throw;
  }

  CUDA_CHECK(cudaFree(device_input));
  CUDA_CHECK(cudaFree(device_gray));
  CUDA_CHECK(cudaFree(device_blur));
  std::cout << "Processed: " << input_path.filename().string() << " ("
            << image.width << "x" << image.height << ")\n";
}

void PrintUsage(const char* program) {
  std::cout << "Usage: " << program
            << " --input <input_directory> --output <output_directory>\n"
            << "Input format: binary PPM (P6), 8-bit RGB.\n";
}

int main(int argc, char* argv[]) {
  try {
    fs::path input_dir;
    fs::path output_dir;

    for (int i = 1; i < argc; ++i) {
      const std::string argument = argv[i];
      if (argument == "--input" && i + 1 < argc) {
        input_dir = argv[++i];
      } else if (argument == "--output" && i + 1 < argc) {
        output_dir = argv[++i];
      } else if (argument == "--help") {
        PrintUsage(argv[0]);
        return 0;
      } else {
        PrintUsage(argv[0]);
        return 1;
      }
    }

    if (input_dir.empty() || output_dir.empty() || !fs::is_directory(input_dir)) {
      PrintUsage(argv[0]);
      throw std::runtime_error("Provide valid --input and --output directories.");
    }

    CUDA_CHECK(cudaFree(nullptr));
    fs::create_directories(output_dir);

    std::vector<fs::path> images;
    for (const auto& entry : fs::directory_iterator(input_dir)) {
      if (entry.is_regular_file() && entry.path().extension() == ".ppm") {
        images.push_back(entry.path());
      }
    }
    std::sort(images.begin(), images.end());

    if (images.empty()) {
      throw std::runtime_error("No .ppm images found in " + input_dir.string());
    }

    std::cout << "Found " << images.size() << " image(s). Starting GPU processing.\n";
    for (const auto& image_path : images) {
      ProcessImage(image_path, output_dir);
    }
    std::cout << "Completed successfully. Images processed: " << images.size()
              << "\n";
  } catch (const std::exception& error) {
    std::cerr << "Error: " << error.what() << "\n";
    return 1;
  }
  return 0;
}
