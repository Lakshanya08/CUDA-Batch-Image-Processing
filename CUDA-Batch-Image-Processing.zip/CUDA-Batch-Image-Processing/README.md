# CUDA-Accelerated Batch Image Processing

A CUDA C++ project that processes a directory of RGB images on an NVIDIA GPU.
For each input image, it creates:
- a grayscale version, using a CUDA pixel-wise kernel;
- a Gaussian-blurred version, using a CUDA 3x3 convolution kernel.

The program processes every `.ppm` file in one input directory during one run.

## Requirements

- NVIDIA GPU with a working CUDA installation
- CUDA Toolkit (`nvcc`)
- C++17-capable host compiler
- `make`

No OpenCV dependency is required. To keep the project portable in CUDA lab
environments, input and output images use binary PPM (P6), 8-bit RGB format.

## Repository layout

```text
CUDA-Batch-Image-Processing/
├── src/
│   └── main.cu
├── input/
│   ├── sample1.ppm
│   ├── sample2.ppm
│   └── sample3.ppm
├── output/
├── results/
├── Makefile
├── run.sh
├── .gitignore
└── README.md
```

## Build

```bash
make
```

## Run

```bash
./image_processing --input input --output output
```

Or use the helper script:

```bash
chmod +x run.sh
./run.sh
```

To see command-line usage:

```bash
./image_processing --help
```

## Input format

The program reads binary PPM (P6) images with an 8-bit maximum channel value
(255). Place one or more `.ppm` files in the input directory. Other formats
such as JPEG and PNG are not supported by this dependency-free example.

## GPU implementation

The program copies RGB image data from host memory to GPU memory. A 2D CUDA
grid with 16x16 threads per block launches two kernels:

1. `GrayscaleKernel`: each thread computes one pixel's grayscale intensity
   using the weighted RGB formula.
2. `GaussianBlurKernel`: each thread computes one output pixel using a
   normalized 3x3 Gaussian-like kernel.

The output buffers are copied back to host memory and saved as PPM files.
Boundary pixels use edge clamping.

## Output

For each `name.ppm` input, the program writes:
- `name_grayscale.ppm`
- `name_blur.ppm`

The terminal reports each processed image and the total number processed.
Execution evidence should be captured from an actual run and saved under
`results/` (for example, a terminal screenshot and a text log).

## Example

```text
Found 3 image(s). Starting GPU processing.
Processed: sample1.ppm (256x256)
Processed: sample2.ppm (256x256)
Processed: sample3.ppm (256x256)
Completed successfully. Images processed: 3
```

The example above illustrates the expected message format; it is not a
record of a run on your machine. Capture your own output for submission.

## Author

Lakshanya N

## Course project

CUDA at Scale for the Enterprise — Independent Project
