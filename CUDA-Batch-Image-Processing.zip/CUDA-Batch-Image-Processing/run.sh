#!/usr/bin/env bash
set -euo pipefail

make
mkdir -p output
./image_processing --input input --output output
